# Intentionally weak token verification

HARDCODED_TOKENS = [
    "admin-token",
    "test-token",
    "12345",
]

def verify_token_insecure(token: str) -> bool:
    # BAD: accepts any token that starts with "test" OR is in a hardcoded list
    if not token:
        return False
    if token in HARDCODED_TOKENS:
        return True
    if token.startswith("test-"):
        return True
    return False
