import sqlite3

def get_user(uid):
    # Raw SQL string
    query = "SELECT * FROM users WHERE id = " + uid
    conn = sqlite3.connect("users.db")
    return conn.execute(query)
