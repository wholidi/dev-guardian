import sqlite3

def get_user_raw_query(user_id: str):
    # BAD: Direct string concatenation → SQL injection
    query = "SELECT id, username, email FROM users WHERE id = '" + user_id + "'"
    conn = sqlite3.connect("users.db")
    cur = conn.cursor()
    try:
        cur.execute(query)
        row = cur.fetchone()
        return {"id": row[0], "username": row[1], "email": row[2]} if row else None
    finally:
        conn.close()
