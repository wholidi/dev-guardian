from flask import Flask, request, jsonify
import os
import json
from db import get_user_raw_query
from auth import verify_token_insecure

app = Flask(__name__)

# DEBUG MODE ENABLED (bad)
app.config["DEBUG"] = True

# HARD-CODED SECRET (bad)
API_SECRET = "super-secret-api-key-123"

@app.route("/health")
def health():
    return jsonify({"status": "ok"})

@app.route("/run")
def run():
    # COMMAND INJECTION (bad)
    cmd = request.args.get("cmd", "echo no-command")
    result = os.popen(cmd).read()
    return jsonify({"output": result})

@app.route("/user", methods=["GET"])
def user():
    # SQL INJECTION (bad)
    user_id = request.args.get("id", "1")
    row = get_user_raw_query(user_id)
    return jsonify({"user": row})

@app.route("/login", methods=["POST"])
def login():
    # INSECURE TOKEN CHECK (bad)
    token = request.headers.get("X-API-TOKEN")
    if not verify_token_insecure(token):
        return jsonify({"error": "invalid token"}), 401

    return jsonify({"status": "logged_in"})

@app.route("/config", methods=["GET"])
def get_config():
    # EXPOSING SENSITIVE CONFIG (bad)
    with open("config/settings.json", "r") as f:
        return jsonify(json.load(f))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
