// BAD: direct use of location.search in innerHTML → XSS
const params = new URLSearchParams(window.location.search);
const name = params.get("name") || "Guest";

document.getElementById("welcome").innerHTML =
  "Hello, " + name + "!";  // vulnerable to <script>alert(1)</script>
