#!/bin/bash

# BAD: uses unvalidated environment variable in rm command
TARGET_DIR=${BACKUP_TARGET:-"/tmp/test-backup"}

echo "Backing up to $TARGET_DIR"
mkdir -p "$TARGET_DIR"

# Extremely dangerous pattern (do NOT use in real systems)
rm -rf "$TARGET_DIR/*"
cp -R . "$TARGET_DIR/"
echo "Backup completed"
