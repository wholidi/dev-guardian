# Insecure configuration file

DB_HOST = "localhost"
DB_USER = "root"
DB_PASSWORD = "rootpassword"  # BAD: hardcoded credentials
JWT_SECRET = "jwt-secret-key-should-not-be-here"
ENABLE_EXPERIMENTAL_FEATURES = True