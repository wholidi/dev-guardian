import logging

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger("test_project")

def log_login_attempt(username: str, password: str):
    # BAD: logging raw password
    logger.warning(f"Login attempt: user={username}, password={password}")
