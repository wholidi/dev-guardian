import os
import flask

app = flask.Flask(__name__)

# Hardcoded secret
API_KEY = "1234567890-SECRET"

# Command injection
@app.route("/run")
def run():
    cmd = flask.request.args.get("cmd")
    return os.popen(cmd).read()

# SQL injection
@app.route("/user")
def user():
    user_id = flask.request.args.get("id")
    query = f"SELECT * FROM users WHERE id = '{user_id}'"
    return query
